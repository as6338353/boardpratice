from django.contrib import admin
from .models import Board, Topic

admin.site.register(Board)
admin.site.register(Topic)

