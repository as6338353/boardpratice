from django.urls import path
from . import views
from users import views as users_views

app_name = 'communitys'
urlpatterns = [
    # /communitys/
    path('', views.main, name='main'),
    # /communitys/board_list/
    # CBV 표현
    path('board_list/', views.BoardListView.as_view(), name='board_list'),

    # FBV 표현
    # path('board_list/', views.board_list, name='board_list'),

    # /communitys/3/
    # CBV 표현
    path('<int:board_id>/', views.TopicListView.as_view(), name='board_topics'),
    # FBV 표현
    # path('<int:board_id>/', views.board_topics, name='board_topics'),

    # /communitys/3/new/    
    path('<int:board_id>/new/', views.board_topic_new, name='board_topic_new'),
    
    # /communitys/3/topics/3
    # CBV 표현
    path('<int:board_id>/topics/<int:topic_id>/', views.PostListView.as_view(), name='board_topic_posts'),
    # FBV 표현 
    # path('<int:board_id>/topics/<int:topic_id>/', views.board_topic_posts, name='board_topic_posts'),

    # /communitys/3/topics/3/reply_topic/   
    path('<int:board_id>/topics/<int:topic_id>/reply/', views.board_reply_topic, name='board_reply_topic'),
    # /communitys/3/topic/3/posts/3/edit/
    path('<int:board_id>/topics/<int:topic_id>/posts/<int:post_id>/edit/', views.PostUpdateView.as_view(), name='board_edit_post'),
]