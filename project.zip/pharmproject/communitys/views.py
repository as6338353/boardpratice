from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
from pharmproject.users.models import User as user_model
from .models import Board, Topic, Post
from .forms import NewTopicForm, PostForm
from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.views.generic import UpdateView, ListView
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# Create your views here.
def main(request):
    return render(request, 'communitys/main.html')

# CBV 표현
class BoardListView(ListView):
    model = Board
    context_object_name = 'boards'
    template_name = 'communitys/board_list.html'

# def board_list(request):
#    boards = Board.objects.all()
#    return render(request, 'communitys/board_list.html', {'boards': boards})


# CBV 표현
class TopicListView(ListView):
    model = Topic
    context_object_name = 'topics'
    template_name = 'communitys/board_topics.html'
    paginate_by = 20

    def get_context_data(self, **kwargs):
        kwargs['board'] = self.board
        return super().get_context_data(**kwargs)

    def get_queryset(self):
        self.board = get_object_or_404(Board, pk=self.kwargs.get('board_id'))
        queryset = self.board.topics.order_by('-last_updated').annotate(replies=Count('posts') - 1)
        return queryset


# def board_topics(request, board_id):
#    board = get_object_or_404(Board, pk=board_id)
#    queryset = board.topics.order_by('-last_updated').annotate(replies=Count('posts') - 1)
#    page = request.GET.get('page', 1)

#    paginator = Paginator(queryset, 20)

#    try:
#        topics = paginator.page(page)
#    except PageNotAnInteger:
        # fallback to the first page
#        topics = paginator.page(1)
#    except EmptyPage:
        # probably the user tried to add a page number
        # in the url, so we fallback to the last page
#        topics = paginator.page(paginator.num_pages)
#    return render(request, 'communitys/board_topics.html', {'board': board, 'topics': topics})

@login_required
def board_topic_new(request, board_id):
    board = get_object_or_404(Board, pk=board_id)
    user = user_model.objects.first()  # TODO: get the currently logged in user

    if request.method == 'POST':
        form = NewTopicForm(request.POST)
        if form.is_valid():
            topic = form.save(commit=False)
            topic.board = board
            topic.starter = user
            topic.save()
            Post.objects.create(
                message=form.cleaned_data.get('message'),
                topic=topic,
                created_by=user
            )
            return redirect('communitys:board_topic_posts', board_id=board_id, topic_id=topic.pk)
    else:
        form = NewTopicForm()
    return render(request, 'communitys/board_topic_new.html', {'board': board, 'form': form})

# CBV표현
class PostListView(ListView):
    model = Post
    context_object_name = 'posts'
    template_name = 'communitys/board_topic_posts.html'
    paginate_by = 2

    def get_context_data(self, **kwargs):

        session_key = 'viewed_topic_{}'.format(self.topic.pk)  # <-- here
        if not self.request.session.get(session_key, False):
            self.topic.views += 1
            self.topic.save()
            self.request.session[session_key] = True           # <-- until here

        kwargs['topic'] = self.topic
        return super().get_context_data(**kwargs)

    def get_queryset(self):
        self.topic = get_object_or_404(Topic, board__pk=self.kwargs.get('board_id'), pk=self.kwargs.get('topic_id'))
        queryset = self.topic.posts.order_by('created_at')
        return queryset

# FBV표현
# def board_topic_posts(request, board_id, topic_id):
#    topic = get_object_or_404(Topic, board__pk=board_id, pk=topic_id)
#    topic.views += 1
#    topic.save()
#    return render(request, 'communitys/board_topic_posts.html', {'topic': topic})

@login_required
def board_reply_topic(request, board_id, topic_id):
    topic = get_object_or_404(Topic, board__pk=board_id, pk=topic_id)
    user = user_model.objects.first()
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.topic = topic
            post.created_by = user
            post.save()

            topic.last_updated = timezone.now()  
            topic.save()  
            topic_url = reverse('communitys:board_topic_posts', kwargs={'board_id': board_id, 'topic_id': topic_id})
            topic_post_url = '{url}?page={page}#{id}'.format(
                url=topic_url,
                id=post.pk,
                page=topic.get_page_count()
            )

            return redirect(topic_post_url)

    else:
        form = PostForm()
    return render(request, 'communitys/board_reply_topic.html', {'topic': topic, 'form': form})


@method_decorator(login_required, name='dispatch')
class PostUpdateView(UpdateView):
    model = Post
    fields = ('message', )
    template_name = 'communitys/board_edit_post.html'
    pk_url_kwarg = 'post_id'
    context_object_name = 'post'

    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.filter(created_by=self.request.user)    

    def form_valid(self, form):
        post = form.save(commit=False)
        post.updated_by = self.request.user
        post.updated_at = timezone.now()
        post.save()
        return redirect('communitys:board_topic_posts', board_id=post.topic.board.id, topic_id=post.topic.id)